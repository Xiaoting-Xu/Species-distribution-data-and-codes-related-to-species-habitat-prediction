##Modeling
rm(list=ls())

##loading required libraries
library(rgdal)
library(raster)
library(biomod2)
library(foreach)
library(doSNOW)
library(ecospat)

library(ggplot2)
library(dplyr)
library(parallel)
library(iterators)
library(lattice)
library(sp)
library(maps) 
library(maptools) 
library(RColorBrewer)
library(ggpubr)
library(ade4)
library(gridExtra)
library(rasterVis)
library(doParallel)
library(gtools)
library(sf)
library(terra)

############################################################################################
##PREPARTION FOR MODELING
############################################################################################


# Import map
dataProjected <- readOGR('map84west.shp')
dataProjected@data$id <- rownames(dataProjected@data)
westPoints <- fortify(dataProjected)
df_Map <- full_join(westPoints, dataProjected@data, by = "id")

# Mapping the study area
p0 <- ggplot()+
  geom_polygon(data = df_Map, aes(x = long, y = lat, group = group), fill='grey', colour="black",linewidth=0.25)+
  coord_quickmap()
p0

# Define the study area as western China: longitude 70E-115E; latitude 20N-50N
west_ext <- extent(70,115,20,50) 
stk_current <- stack(list.files(path = paste0("WorldClim_data/current"),
                                pattern = "Bio_", 
                                full.names = T), 
                     RAT = FALSE)
stk_west_current <- crop(stk_current, west_ext) 

# Changing the output style
par(mfrow=c(1, 4)) 
col1 <- hcl.colors(100, "red-green", rev = T)

stk_west_current_sub <- stack(subset(stk_west_current, c("Bio_05", "Bio_06", "Bio_16", "Bio_17")))
par(mfrow=c(1, 4))

# Plots of the four selected bioclimatic variables in the study area
plot(stk_west_current, c("Bio_05", "Bio_06", "Bio_16", "Bio_17"), col=col1) + coord_quickmap()

#########################################################################################################  
##SPECIES DISTRIBUTION MODEL
#########################################################################################################

# the list of species
sp.list.bivar <- read.table("2species_bivar.txt")
sp.list.bivar <- as.character(sp.list.bivar[,1])

## get model parameters
mod.id = "mod1"
mod.models = c( "GLM" , "GBM" , "GAM" , "CTA", "ANN", 
                "SRE" , "FDA" , "MARS", "RF" ,"MAXNET" )
mod.n.rep = 3
mod.data.split = 80
mod.prevalence = 0.5

### Gentiana yunnanensis ###

sp = sp.list.bivar[1]
spif <- sub(" ",".",sp) 

##Species distribution point
sp.occ <- read.table(paste0(sp,"_distribution.csv"), header = TRUE, sep = ",")

# Convert data to a format usable for modeling
sp.form <- BIOMOD_FormatingData(resp.var = rep(1, nrow(sp.occ)), 
                                expl.var = stk_west_current_sub,
                                resp.xy = sp.occ[, c("X_WGS84", "Y_WGS84")],
                                resp.name = sp, 
                                PA.nb.rep = 2,
                                PA.nb.absences = 1000,
                                PA.strategy = "random")
plot(sp.form)
ggsave(paste0(sp,"_PAview.png"))

# define models options
bm.opt <- BIOMOD_ModelingOptions()

### Calibration of simple bivariate models
esm.mod<-BIOMOD_Modeling( bm.format = sp.form, 
                          models = mod.models,
                          bm.options = bm.opt, 
                          nb.rep = mod.n.rep, 
                          data.split.perc = mod.data.split,
                          prevalence = mod.prevalence,
                          do.full.models = F,
                          modeling.id = mod.id,
                          save.output = TRUE)
save(esm.mod, file = paste0(sp,"_mod"))

# Analysis of model evaluation
models.scores <- get_evaluations(esm.mod)
write.csv(models.scores,file = paste0(sp,"_modscores.csv"))
bm_PlotEvalBoxplot(bm.out = esm.mod, group.by = c('algo', 'algo')) 
ggsave(paste0(sp,"_modelscroresview.png"))


### Evaluation and average of simple bivariate models to ESMs
esm.em <- BIOMOD_EnsembleModeling(bm.mod = esm.mod, 
                                  models.chosen = "all",
                                  em.by = "all",
                                  em.algo = c("EMmean"),
                                  metric.select = "TSS", 
                                  metric.select.thresh = c(0.8),
                                  metric.eval = c("TSS", "ROC"), 
                                  prob.mean = FALSE,
                                  prob.cv = TRUE,
                                  committee.averaging = TRUE,
                                  prob.mean.weight = TRUE, 
                                  var.import = 0)
save(esm.em,file = paste0(sp,"_em"))
ensemble.models.scores <- get_evaluations(esm.em)
write.csv(ensemble.models.scores,file = paste0(sp,"_emmodscores.csv"))
bm_PlotEvalBoxplot(bm.out = esm.em, group.by = c('algo', 'algo')) 
ggsave(paste0(sp,"_emmodelscroresview.png"))


### Gentiana siphonantha ###

sp = sp.list.bivar[2]
spif <- sub(" ",".",sp) 


##Species distribution point
sp.occ <- read.table(paste0(sp,"_distribution.csv"), header = TRUE, sep = ",")

# Convert data to a format usable for modeling
sp.form <- BIOMOD_FormatingData(resp.var = rep(1, nrow(sp.occ)), 
                                expl.var = stk_west_current_sub,
                                resp.xy = sp.occ[, c("X_WGS84", "Y_WGS84")],
                                resp.name = sp, 
                                PA.nb.rep = 2,
                                PA.nb.absences = 1000,
                                PA.strategy = "random")
plot(sp.form)
ggsave(paste0(sp,"_PAview.png"))

# define models options
bm.opt <- BIOMOD_ModelingOptions()

### Calibration of simple bivariate models
esm.mod<-BIOMOD_Modeling( bm.format = sp.form, 
                          models = mod.models,
                          bm.options = bm.opt, 
                          nb.rep = mod.n.rep, 
                          data.split.perc = mod.data.split,
                          prevalence = mod.prevalence,
                          do.full.models = F,
                          modeling.id = mod.id,
                          save.output = TRUE)
save(esm.mod,file = paste0(sp,"_mod"))

# Analysis of model evaluation析
models.scores <- get_evaluations(esm.mod)
write.csv(models.scores,file = paste0(sp,"_modscores.csv"))
bm_PlotEvalBoxplot(bm.out = esm.mod, group.by = c('algo', 'algo')) 
ggsave(paste0(sp,"_modelscroresview.png"))


### Evaluation and average of simple bivariate models to ESMs
esm.em <- BIOMOD_EnsembleModeling(bm.mod = esm.mod, 
                                  models.chosen = "all",
                                  em.by = "all",
                                  em.algo = c("EMmean"),
                                  metric.select = "TSS", 
                                  metric.select.thresh = c(0.8),
                                  metric.eval = c("TSS", "ROC"), 
                                  prob.mean = FALSE,
                                  prob.cv = TRUE,
                                  committee.averaging = TRUE,
                                  prob.mean.weight = TRUE, 
                                  var.import = 0)
save(esm.em,file = paste0(sp,"_em"))
ensemble.models.scores <- get_evaluations(esm.em)
write.csv(ensemble.models.scores,file = paste0(sp,"_emmodscores.csv"))
bm_PlotEvalBoxplot(bm.out = esm.em, group.by = c('algo', 'algo')) 
ggsave(paste0(sp,"_emmodelscroresview.png"))

