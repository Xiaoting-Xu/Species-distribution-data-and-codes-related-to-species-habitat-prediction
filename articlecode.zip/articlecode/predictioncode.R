# prodiction
rm(list=ls())

# loading required libraries
library(rgdal)
library(raster)
library(biomod2)
library(foreach)
library(doSNOW)

library(lattice)
library(rasterVis)
library(dplyr)
library(ggplot2)

sp.list <- c("Gentiana yunnanensis","Gentiana siphonantha")

for.binary.meth = c("TSS")
ens.models.eval.meth = c("TSS")
west_ext <- extent(70,115,20,50) 

s.time=Sys.time()

cl<- makeCluster(5,outfile="")
registerDoSNOW(cl)

### Gentiana yunnanensis ###

sp <- sp.list[1]

# the list of climate scenarios
pro.folder.list<-c("baseline",
                   "ACCESS-CM2_2060_245","ACCESS-CM2_2060_585","ACCESS-CM2_2100_245","ACCESS-CM2_2100_585",
                   "BCC-CSM2-MR_2060_245","BCC-CSM2-MR_2060_585","BCC-CSM2-MR_2100_245","BCC-CSM2-MR_2100_585",
                   "CMCC-ESM2_2060_245","CMCC-ESM2_2060_585","CMCC-ESM2_2100_245","CMCC-ESM2_2100_585",
                   "MPI-ESM1-2-HR_2060_245","MPI-ESM1-2-HR_2060_585","MPI-ESM1-2-HR_2100_245","MPI-ESM1-2-HR_2100_585",
                   "UKESM1-0-LL_2060_245","UKESM1-0-LL_2060_585","UKESM1-0-LL_2100_245","UKESM1-0-LL_2100_585",
                   "multi_GCMs_2060_245","multi_GCMs_2060_585","multi_GCMs_2100_245","multi_GCMs_2100_585"
                   )

iterations <- length(pro.folder.list)
pb <- txtProgressBar(max = iterations, style = 3) # pb show progress
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress = progress)

foreach (sceid = 1:length(pro.folder.list), .packages = c("raster","rgdal","doSNOW","foreach","biomod2","ggplot2"),
         .verbose = TRUE,.combine = rbind,.options.snow = opts) %dopar%{ 
           
           sce = pro.folder.list[sceid]   
           proj.name.para <- sce
           
           #load explanatory variables
           var.name.vector <- c("Bio_05", "Bio_06", "Bio_16", "Bio_17")
           
           a=Sys.time()
           
           
           ## Reading environmental data
           expl.var.para <- stack(paste0(var.name.vector,".tif"))
           expl.var.para.west <- crop(expl.var.para, west_ext) 
           
           ## project models onto the scenarios 
 
           
           ##ensemble models by all models
           load(paste0(sp,"/",sp,"_em"))
           bm.ef<-BIOMOD_EnsembleForecasting(bm.em = esm.em,
                                             proj.name = proj.name.para,
                                             new.env = expl.var.para.west,
                                             models.chosen = "all",
                                             metric.binary = ens.models.eval.meth,
                                             metric.filter = "all")
           save(bm.ef,file = paste0(sp,"/",sp,"_bmef_",proj.name.para))
           plot(bm.ef)
           ggsave(paste0(sp,"_emmodel_sdmap_",proj.name.para,".png"),width = 8, height = 6)
           
           b2=Sys.time()-a
           b2
         }

e.time=Sys.time()
e.time-s.time
close(pb)
stopCluster(cl)
e.time=Sys.time()
e.time-s.time   

### Gentiana siphonantha ###

sp <- sp.list[2]

# the list of climate scenarios
pro.folder.list<-c("baseline",
                   "ACCESS-CM2_2060_245","ACCESS-CM2_2060_585","ACCESS-CM2_2100_245","ACCESS-CM2_2100_585",
                   "BCC-CSM2-MR_2060_245","BCC-CSM2-MR_2060_585","BCC-CSM2-MR_2100_245","BCC-CSM2-MR_2100_585",
                   "CMCC-ESM2_2060_245","CMCC-ESM2_2060_585","CMCC-ESM2_2100_245","CMCC-ESM2_2100_585",
                   "MPI-ESM1-2-HR_2060_245","MPI-ESM1-2-HR_2060_585","MPI-ESM1-2-HR_2100_245","MPI-ESM1-2-HR_2100_585",
                   "UKESM1-0-LL_2060_245","UKESM1-0-LL_2060_585","UKESM1-0-LL_2100_245","UKESM1-0-LL_2100_585",
                   "multi_GCMs_2060_245","multi_GCMs_2060_585","multi_GCMs_2100_245","multi_GCMs_2100_585"
)

iterations <- length(pro.folder.list)
pb <- txtProgressBar(max = iterations, style = 3) # pb show progress
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress = progress)

foreach (sceid = 1:length(pro.folder.list), .packages = c("raster","rgdal","doSNOW","foreach","biomod2","ggplot2"),
         .verbose = TRUE,.combine = rbind,.options.snow = opts) %dopar%{ 
           
           sce = pro.folder.list[sceid]   
           proj.name.para <- sce
           
           #load explanatory variables
           var.name.vector <- c("Bio_05", "Bio_06", "Bio_16", "Bio_17")
           
           a=Sys.time()
           
           
           ## Reading environmental data
           expl.var.para <- stack(paste0(var.name.vector,".tif"))
           expl.var.para.west <- crop(expl.var.para, west_ext) 
           
           ## project models onto the scenarios 
           
           
           ##ensemble models by all models
           load(paste0(sp,"/",sp,"_em"))
           bm.ef<-BIOMOD_EnsembleForecasting(bm.em = esm.em,
                                             proj.name = proj.name.para,
                                             new.env = expl.var.para.west,
                                             models.chosen = "all",
                                             metric.binary = ens.models.eval.meth,
                                             metric.filter = "all")
           save(bm.ef,file = paste0(sp,"/",sp,"_bmef_",proj.name.para))
           plot(bm.ef)
           ggsave(paste0(sp,"_emmodel_sdmap_",proj.name.para,".png"),width = 8, height = 6)
           
           b2=Sys.time()-a
           b2
         }

e.time=Sys.time()
e.time-s.time
close(pb)
stopCluster(cl)
e.time=Sys.time()
e.time-s.time   