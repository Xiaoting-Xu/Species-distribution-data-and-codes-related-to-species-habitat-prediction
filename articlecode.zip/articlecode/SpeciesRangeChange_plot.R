library(biomod2)


sp.list <- c("Gentiana yunnanensis","Gentiana siphonantha")
#pro.folder.list<-c("baseline",
#                   "ACCESS-CM2_2060_245","ACCESS-CM2_2060_585","ACCESS-CM2_2100_245","ACCESS-CM2_2100_585",
 #                  "BCC-CSM2-MR_2060_245","BCC-CSM2-MR_2060_585","BCC-CSM2-MR_2100_245","BCC-CSM2-MR_2100_585",
  #                 "CMCC-ESM2_2060_245","CMCC-ESM2_2060_585","CMCC-ESM2_2100_245","CMCC-ESM2_2100_585",
   #                "MPI-ESM1-2-HR_2060_245","MPI-ESM1-2-HR_2060_585","MPI-ESM1-2-HR_2100_245","MPI-ESM1-2-HR_2100_585",
    #               "UKESM1-0-LL_2060_245","UKESM1-0-LL_2060_585","UKESM1-0-LL_2100_245","UKESM1-0-LL_2100_585",
     #              "multi_GCMs_2060_245","multi_GCMs_2060_585","multi_GCMs_2100_245","multi_GCMs_2100_585",
      #             "4GCMs_2060_245","4GCMs_2060_585","4GCMs_2100_245","4GCMs_2100_585")

pro.folder.list<-c("baseline","4GCMs_2060_245","4GCMs_2060_585","4GCMs_2100_245","4GCMs_2100_585")
#pro.folder.list<-c("baseline","ACCESS-CM2_2060_245","ACCESS-CM2_2060_585","ACCESS-CM2_2100_245","ACCESS-CM2_2100_585")
#pro.folder.list<-c("baseline","BCC-CSM2-MR_2060_245","BCC-CSM2-MR_2060_585","BCC-CSM2-MR_2100_245","BCC-CSM2-MR_2100_585")
#pro.folder.list<-c("baseline","CMCC-ESM2_2060_245","CMCC-ESM2_2060_585","CMCC-ESM2_2100_245","CMCC-ESM2_2100_585")
#pro.folder.list<-c("baseline","MPI-ESM1-2-HR_2060_245","MPI-ESM1-2-HR_2060_585","MPI-ESM1-2-HR_2100_245","MPI-ESM1-2-HR_2100_585")
#pro.folder.list<-c("baseline","UKESM1-0-LL_2060_245","UKESM1-0-LL_2060_585","UKESM1-0-LL_2100_245","UKESM1-0-LL_2100_585")
#pro.folder.list<-c("baseline","multi_GCMs_2060_245","multi_GCMs_2060_585","multi_GCMs_2100_245","multi_GCMs_2100_585")

## Gentiana yunnanensis
sp <- sp.list[1]
spif <- sub(" ",".",sp)


# load the binary files
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[1]))
proj_current <- get_predictions(bm.ef,
                                metric.binary = "TSS",
                                model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[2]))
proj_2060_ssp245 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[3]))
proj_2060_ssp585 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[4]))
proj_2100_ssp245 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[5]))
proj_2100_ssp585 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)


# Compute differences
myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2060_ssp245)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2060_ssp585)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2100_ssp245)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2100_ssp585)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

# Represent main results 
bm_PlotRangeSize(bm.range = myBiomodRangeSize)

## Gentiana siphonantha
sp <- sp.list[2]
spif <- sub(" ",".",sp)


# load the binary files
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[1]))
proj_current <- get_predictions(bm.ef,
                                metric.binary = "TSS",
                                model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[2]))
proj_2060_ssp245 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[3]))
proj_2060_ssp585 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[4]))
proj_2100_ssp245 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)
load(paste0(sp,"/",sp,"_bmef_",pro.folder.list[5]))
proj_2100_ssp585 <- get_predictions(bm.ef,
                                    metric.binary = "TSS",
                                    model.as.col = TRUE)


# Compute differences
myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2060_ssp245)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2060_ssp585)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2100_ssp245)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

myBiomodRangeSize <- BIOMOD_RangeSize(proj.current = proj_current, proj.future = proj_2100_ssp585)
myBiomodRangeSize$Compt.By.Models
plot(myBiomodRangeSize$Diff.By.Pixel)

# Represent main results 
bm_PlotRangeSize(bm.range = myBiomodRangeSize)